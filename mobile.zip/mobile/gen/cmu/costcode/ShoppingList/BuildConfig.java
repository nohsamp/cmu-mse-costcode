/** Automatically generated file. DO NOT MODIFY */
package cmu.costcode.ShoppingList;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}